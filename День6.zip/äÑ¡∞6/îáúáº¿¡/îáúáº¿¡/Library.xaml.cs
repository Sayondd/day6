﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using static WSUniversalLib.Class1;

namespace Магазин
{
    /// <summary>
    /// Логика взаимодействия для Library.xaml
    /// </summary>
    public partial class Library : Window
    {
        public Library()
        {
            InitializeComponent();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            MaterialCalculator calculator = new MaterialCalculator();
            double totalMat = calculator.CalculateMaterial(Convert.ToInt32(countProduct.Text), Convert.ToDouble(width.Text),
            Convert.ToDouble(lenght.Text), Convert.ToInt32(typeProduct.Text), Convert.ToInt32(typeMaterial.Text));
            answers.Text = "Ответ: " + totalMat;
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            countProduct.Text = "";
            width.Text = "";
            lenght.Text = "";
            typeProduct.Text = "";
            typeMaterial.Text = "";
            answers.Text = "";
        }
    }
}
